<template>
    <div class="help-page">
      <h1>Support</h1>
      <p>
        Vous avez besoin d'aide ? Consultez nos articles pour trouver des réponses ou contactez notre support.
      </p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'HelpPage',
  };
  </script>
  
  <style>
  .help-page {
    padding: 20px;
    max-width: 800px;
    margin: 0 auto;
  }
  
  .help-page h1 {
    text-align: center;
    margin-bottom: 20px;
  }
  
  .help-page p {
    text-align: justify;
    line-height: 1.6;
  }
  </style>
  