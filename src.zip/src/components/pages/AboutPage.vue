<template>
    <div class="about-page">
      <h1>À propos</h1>
      <p>
        Bienvenue sur la page À propos. Ici, vous pouvez en savoir plus sur notre mission, notre équipe, et les raisons pour lesquelles nous avons créé cette plateforme.
      </p>
    </div>
  </template>
  
  <script>
  export default {
    name: 'AboutPage',
  };
  </script>
  
  <style>
  .about-page {
    padding: 20px;
    max-width: 800px;
    margin: 0 auto;
  }
  
  .about-page h1 {
    text-align: center;
    margin-bottom: 20px;
  }
  
  .about-page p {
    text-align: justify;
    line-height: 1.6;
  }
  </style>
  